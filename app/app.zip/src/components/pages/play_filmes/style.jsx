import styled from 'styled-components';

export const Bodyy = styled.body`
.player{
    margin: auto;
}

`;
export default Bodyy