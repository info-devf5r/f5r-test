import styled from 'styled-components';

const Bodyy = styled.body`


.background {
    position: fixed;
    width: 100%;
    height: 100%;
    margin: auto;
}

.ze{
    /*text-decoration: none; */
    overflow :initial;
    cursor: pointer;
}

.group_B {
    padding-top: 7vmax;
}

h1 {
    position: relative;
    font-size: 20px;
    color: #cecece;
    padding-left: 35px;
}
h2 {
    position: relative;
    font-size: 2vmax;
    color: #cecece;
    margin-left: 4vmax;
    margin-bottom: 2vmax;
}
`;

export default Bodyy;