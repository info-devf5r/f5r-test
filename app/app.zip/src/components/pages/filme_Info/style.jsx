import styled from 'styled-components';

const Bodyy = styled.body`
  
`;
export default Bodyy