import React, { Component } from 'react';

//import api from './api';
class Filmes extends Component{
    render() {
        return(
            <div>
                    sla
            </div>
        )
    }
}

export default Filmes;