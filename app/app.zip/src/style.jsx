import styled from 'styled-components'

const Bodyy = styled.body`
.background{
    position: fixed;
    margin: auto;
    width: 100%;
    height: 100%;
}

`;

export default Bodyy;