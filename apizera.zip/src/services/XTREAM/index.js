Object.defineProperty(exports, '__esModule', { value: true })

module.exports = {
  Player: require('./Player')
}
