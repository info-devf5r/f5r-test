//const app = require('./src/config/server-config');
const axios = require('axios');

//axios.post('http://adm.painelip.com:3000/check_phone')
//.then(console.log)

phone = "17991380095"

